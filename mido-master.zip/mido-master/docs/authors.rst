Authors
=======

Ole Martin Bjørndalen (lead programmer)

Rapolas Binkys
