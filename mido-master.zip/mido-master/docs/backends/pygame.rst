Pygame
------

Name: ``mido.backends.pygame``

The Pygame backend uses ``pygame.midi`` for I/O.

Doesn't receive ``active_sensing``.

Callbacks are currently not implemented.

Pygame.midi is implemented on top of PortMidi.
